import {
    world,
    // Import world
    system,
    // Import system
    Player,
    // Import Player
    Container,
    //Import Container
    BlockVolume,
    // Import BlockVolume
    Entity,
    // Import Entity
    TicksPerSecond
} from '@minecraft/server'; //From Minecraft/server

import {
    ActionFormData,
    // new ActionFormData
    ModalFormData,
    // new ModalFormData
    MessageFormData
    //new MessageFormData
} from '@minecraft/server-ui'; //From Minecraft/server-ui



import { Storage } from "./LoshaData.js";
import Vector3 from 'LoshaVector.js';
import convert from "LoshaConvert.js";

const areas = new Storage("protectedAreas");
const limitData = new Storage("limitData");
const players = new Storage("players");




// down line for each button in action form
const downLine = "§o§3@LOSHA_MODS";



// icons
const warn = "§r§r - ";
const error = "§r§r - ";
const warnIcon = "";
const youtube = "";
const errorIcon = "";
const protectedTotem = "§r - ";
const glassFind = "";
const settingsIcon = "\uE1A1";
const settingsIcon1 = "\uE1A2";
const waitingIcon = "\uE066";
const waitingIcon1 = "\uE076";
const playerIcon = "\uE077";
const protectedIcon = "\uE0B2";
const diamondIcon = '\uE083';
const swordIcon = "\uE040";
const dieIcon = "\uE031";
const iron = "\uE086";
const chestIcon = "\uE91E";
const interactIcon = "\uE90F";



// Map()
const runs = new Map();
const coords = new Map();
const cooldown = new Map();


const ids = [
    "Q","W","E","R","T","Y","U","I","O","P","A","S","D","F","G","H","J","K","L","Z","X","C","V","B","N","M","1","2","3","4","5","6","7","8","9"
];

// return Math[random]
function randomNumber () {
    return Math.floor(Math.random() * 10);
}

// generate keys
function generateLosha (playerName) {
    let id = `${playerName.replace(/ /g, "")}_`;
    do {
        id = id;
        for (let i = 0; i < 5; i++) {
            id += ids[Math.floor(Math.random() * ids.length)];
        }
    } while (areas.has(id));
    return `${id}Area`;
}



// Main form
function mainForm (player) {
    let myareas = areas.all().filter(
        (area) => area.owner == player.name
    );
    if (myareas.length!=0){
        mainForm_1(player);
        return;
    }
    let shortcut1 = myareas.length == 0 ? "\n§fYOU §4DON'T§f HAVE ANY AREAS!!.\n\n": "";
    const{x, y, z} = player.location;
    const block = player.dimension.getBlock(
            new Vector3(x, y-1, z));
    const area = Main.getAreaByLocation(block.location);
    let shortcut="";
    if (area && area.settings.showInformation == true) {
        shortcut = `\n\n${warn}§aAREA NAME§r - §b${area.name}\n${warn}§aAREA FROM§r - §b${x+", "+y+", "+z}\n${warn}§aAREA TO§r - §b${tx+", "+ty+", "+tz}\n${warn}§aAREA WHITLIST§r - §b${generateAreaWhitlist(area)}\n${warn}§aAREA OWNER§r - §b${area.owner}\n\n`;
    }else if (area && isAdmin(player)) {
        shortcut = `\n\n${warn}§aAREA NAME§r - §b${area.name}\n${warn}§aAREA WHITLIST§r - §b${generateAreaWhitlist(area)}\n${warn}§aAREA OWNER§r - §b${area.owner}\n\n`;
    }
    let form = new ActionFormData()
           .title("§f§o[ Main Form ]")
           .body("§f§oHello!, §aThis is §bLosha lock mod§f!!"+shortcut1+shortcut)
           .button(`CREATE AREA\n${downLine}`, "textures/ui/color_plus.png")
           
            .button(`HOU TO USE\n${downLine}`, "textures/ui/how_to_play_button_default_light.png")
            .button(`EXIT\n${downLine}`, "textures/ui/cancel.png")
           let isOwner = player.hasTag("LoshaAdmin");
           
           if (player.isOp() || isOwner) {
               form.button("§eADMIN PANEL\n" + downLine, "textures/ui/op.png")
           }
           form.show(player).then(({ canceled, selection })=>{
               if(canceled) return;
               
               switch (selection) {
                   case 0:
                       creatingform(player);
                       break;
                   case 1:
                       howToUse(player);
                       break;
                   case 2:
                       
                       break;
                   case 3:
                       adminpanel(player);
                       break;
               }
           })
}
function mainForm_1 (player) {
    let myareas = areas.all().filter(
        (area) => area.owner == player.name
    );
    const{x, y, z} = player.location;
    const block = player.dimension.getBlock(
            new Vector3(x, y-1, z));
    const area = Main.getAreaByLocation(block.location);
    let shortcut="";
    if (area && area.settings.showInformation == true) {
        shortcut = `\n\n${warn}§aAREA NAME§r - §b${area.name}\n${warn}§aAREA WHITLIST§r - §b${generateAreaWhitlist(area)}\n${warn}§aAREA OWNER§r - §b${area.owner}\n\n`;
    } else if (area && isAdmin(player)) {
        shortcut = `\n\n${warn}§aAREA NAME§r - §b${area.name}\n${warn}§aAREA WHITLIST§r - §b${generateAreaWhitlist(area)}\n${warn}§aAREA OWNER§r - §b${area.owner}\n\n`;
    }
    let form = new ActionFormData()
     .title("§f§o[ Main Form ]")
     .body("§f§oHello!, §aThis is §bLosha lock mod§f!!"+shortcut)
                .button(`CREATE AREA\n${downLine}`, "textures/ui/color_plus.png")
                
           .button(`MY AREAS\n${downLine}`, "textures/items/losha_lock.png")
           .button(`DELETE AREAS\n${downLine}`, "textures/ui/icon_trash.png")
           
            .button(`HOU TO USE\n${downLine}`, "textures/ui/how_to_play_button_default_light.png")
            .button(`EXIT\n${downLine}`, "textures/ui/cancel.png")
           let isOwner = player.hasTag("LoshaAdmin");
           
           if (player.isOp() || isOwner) {
               form.button("§eADMIN PANEL\n" + downLine, "textures/ui/op.png")
           }
           form.show(player).then(({ canceled, selection})=>{
               if(canceled)return;
               switch(selection) {
                   case 0:
                       creatingform(player);
                       break;
                   case 1:
                       ownAreas(player);
                       break;
                   case 2:
                       deleteAreas(player);
                       break;
                   case 3:
                       howToUse(player);
                       break;
                   case 4:
                       return;
                       break;
                   case 5:
                       adminpanel(player);
                       break;
               }
           })
     
}

function creatingform (player) {
    let c1='',
        c2='';
    if (coords.has(player) && runs.has(player)) {
        c1 = coords.get(player)[0];
        c2 = coords.get(player)[1];
    }
    let form = new ModalFormData()
       .title("§o§f[ Creating Form ]")
       .textField("§oWelcome to creating form!!. to create area add the area name, you can add arabic name!, and area from, to,§r "+`\n\n${warn}§rAREA NAME`, "ENTER THE AREA NAME")
       .textField(`${warn}AREA FROM`, "ENTER AREA FROM. PLEASE THE AREA FROM IS COORDS!", c1)
       .textField(`${warn}AREA TO`, "ENTER AREA TO.", c2)
       .submitButton(warn+"§a§oCREATE")
       .show(player).then(({ formValues, canceled }) =>{
           if(canceled) {
              if (!coords.has(player) && !runs.has(player)) return;
              for (const run of runs.get(player)) {
                  system.clearRun(run);
              }
              runs.delete(player);
              coords.delete(player);
              cooldown.delete(player);
              return;
           }
           if (!coords.has(player) && !runs.has(player)) { } else {
               
           
               for (const run of runs.get(player)) {
                   system.clearRun(run);
              }
              runs.delete(player);
              coords.delete(player);
              cooldown.delete(player);
           }
           
           
           const [name, from, to,a] = formValues;
           const [fx, fy, fz] = from.split(" ").map(parseFloat);
           const [tx, ty, tz] = to.split(" ").map(parseFloat);
           if (name.length >= 10) {
               player.sendMessage(error+"§cThe name must be less or equal to 10.")
               return;
           }
           if (
               isNaN(fx) ||
               isNaN(fy) ||
               isNaN(fz) ||
               isNaN(tx) ||
               isNaN(ty) ||
               isNaN(tz) ||
               name == ''
           ) {
               player.sendMessage(error + "§cTHERE ARE ERRORS IN VALUES.!!");
               player.playSound("random.break");
               return;
           }
           const thereAreArea_here = areas.all().some(
               (area) => 
                    new BlockVolume(area.from, area.to).intersects(
          new BlockVolume(
            new Vector3(fx, fy + 60, fz),
            new Vector3(tx, ty - 10, tz)
          )
        ) && area.dimension === player.dimension.id
           );
           
           if (
               thereAreArea_here
           ) {
               player.sendMessage(error+"§cTHERE ARE AREA HERE!, TRY ANOTHER COORDS!!.");
               player.playSound("random.break");
               return;
           }
           
           
           const limit = limitData.get('limit');
           
           
           
           const playerareas = areas.all().filter(area=>area.owner==player.name);
           if(playerareas.length>=limit){
               player.sendMessage(error+"§cYOU ARE UP TO THE LIMIT!!.");
               player.playSound("random.break");
               return;
           }
           const losha = generateLosha(player.name);
           areas.set(losha, {
               name: convert(name),
               from: new Vector3(fx, -64, fz),
               to: new Vector3(tx, 319, tz),
               dimension: player.dimension.id,
               losha,
               owner: player.name,
               y_: fy,
               warns: [],
               messages: [],
               whitelist: [],
               
               settings: {
                   showInformation: false,
                   exclusionPlayers: false,
                   interactWithBlocks: false,
                   showBorder: true,
                   whitelistLength: "I",
                   UseItems: true,
                   canPlaceBlock: false,
                   canBreakBlock: false,
                   canInteractWithBlock: false,
                   killPlayers: false,
                   sendAlertsForArea: true
               }
           });
           player.sendMessage(warn+"§aThe area has been saved!!.");
           player.playSound("random.levelup");
           
       });
}

function ownAreas (player) {
    let myareas = areas.all().filter(
        (area) => area.owner == player.name
    );
    let form = new ActionFormData()
         .title("§o§f[ MY AREAS FORM ]")
         .body(`WELCOME TO MY AREAS FORM!!. ${warn}You have ` + myareas.length + ` AREA!!, CHOSE AREA TO SHOW INFORMATION OF AREA.`)
         myareas.forEach(area =>{
             let dimension_color = area.dimension.includes("overworld")?"§a":area.dimension.includes("nether")?"§4":"§q";
             form.button(`${area.name}\n${dimension_color}§o${area.dimension.replace("minecraft:", "")}`, 'textures/items/losha_lock.png')
         });
         form.show(player).then(({ canceled, selection })=>{
             if(canceled) return;
             const area = myareas[selection];
             if(area) {
                 const{x,y,z} = area.from;
                 const tx=area.to.x,
                       ty=area.to.y,
                       tz=area.to.z;
                let form_ = new ActionFormData()
                .title(area.name)
                .body(`${warn}§aAREA NAME§r - §b${area.name}\n${warn}§aAREA FROM§r - §b${x+", "+y+", "+z}\n${warn}§aAREA TO - §b${tx+", "+ty+", "+tz}\n${warn}§aAREA LAND - §b${land(area.from, area.to)}\n${warn}§aAREA WHITLIST - §b${generateAreaWhitlist(area)}`)
                .button("ACCESS OPTINS\n"+downLine, "textures/ui/icon_multiplayer.png")
                .button("CHANGE NAME\n"+downLine, "textures/ui/pencil_edit_icon.png")
                .button("AREA SETTINGS\n"+downLine, "textures/ui/gear.png")
                .show(player)
                .then(a=>{
                    if(a.canceled)return;
                    switch(a.selection){
                        case 0:
                            accessOptins(player, area); 
                            break;
                            break;
                        case 1:
                            let formm = new ModalFormData()
                                .title(area.name)
                                .textField("§oTO CHANGE AREA NAME ADD NEW NAME!, NAME:", "ENTER NEW NAME", area.name)
                                .submitButton(warn+"§o§aCHANGE")
                                .show(player).then(r=>{
                                    if(r.canceled) return;
                                    const[name] = r.formValues;
                                    if(name==""){
                                        player.sendMessage(error+"§cTHE NAME CAN'T BE AN EMPTY!!.");
                                        return;
                                    }
                                    areas.update(area.losha, v=>{
                                        let nv=v;
                                        nv.name = convert(name);
                                        return nv;
                                    });
                                    player.sendMessage(warn+"§aDone change area name!!?.")
                                })
                            break;
                        case 2:
                            areaSettings(player, area);
                            break;
                    }
                })
             }
         })
}
function land (c1, c2) {
    const {x,y,z}=c1;
    const x1=c2.x,
          y1=c2.y,
          z1=c2.z;
    const x_ = Math.min(x1, x);
    const x_x = Math.max(x1, x);
    const z_ = Math.min(z1, z);
    const z_z = Math.max(z1, z);
    return (x_x - x_ + 1) * (z_ - z_z + 1);
}
function deleteAreas (player) {
    let myareas = areas.all().filter(
        (area) => area.owner == player.name
    );
    let form=new ModalFormData()
        .title("§o§f[ DELETE FORM ]")
        .dropdown(`§oWELCOME TO DELETE FORM!!. ${warn}CHOSE ANY AREA TO DELETE.`, myareas.map(p=>p.name))
        .submitButton(warn+"§o§cDELETE!!")
        .show(player).then(r=>{
            if(r.canceled)return;
            
            const v = r.formValues[0];
            
            let form_ = new MessageFormData()
                .title(myareas[v].name)
                .body(`${warnIcon}: ARE YOU SURE TO §4DELETE§r THIS AREA ( ` + myareas[v].name + ` ) ?!.`)
                .button1("REJECTED")
                .button2("YES, I'M SURE")
                .show(player)
                .then(({ selection })=> {
                    switch (selection) {
                        case 0:
                            return;
                            break;
                        case 1:
                            player.sendMessage(warn+"§aThe area has been deleted!!.");
                            player.playSound("random.levelup");
                            areas.delete(myareas[v].losha);
                            break;
                    }
                });
        });
}

function addAccess (player, area) {
    let worldPlayers = getPlayers().filter(t => t.name != player.name).map(s => s.name)
    if (worldPlayers.length == 0) {
        player.sendMessage(error+"§cThere no players in this world.")
        player.playSound("random.break")
        return;
    }
    
    let form = new ModalFormData()
       .title("§o§f[ ACCESS FORM ]")
       .dropdown("Hello, chose the player to add!?", worldPlayers)
       .submitButton(warn+"§aAdd")
       .show(player)
       .then(({ canceled, formValues }) => {
           if (canceled) return;
           const [index] = formValues;
           const playerIndexed = worldPlayers[index];
           
           if (playerIndexed) {
               if (area.whitelist.includes(playerIndexed)) {
                   player.sendMessage(error+`§c${playerIndexed} aleardy in area whitelist.`)
                   player.playSound("random.break")
                   return;
               }
               
               player.sendMessage(warn+"§eHe in area whitelist now!!.")
               player.playSound("random.levelup")
               areas.update(area.losha, (areaWhiteList) => {
                   let areaValue = areaWhiteList
                   areaValue.whitelist.push(playerIndexed);
                   return areaValue;
               });
           }
       })
}
function deleteAccess(player, area) {
    if(area.whitelist.length==0) {
        player.sendMessage(error+"§cTHIS AREA WHITELIST LENGTH IS 0!!!.")
    }else{
        let players_ = area.whitelist
        let form = new ModalFormData()
            .title("§o§f[ ACCESS FORM ]")
            .dropdown("WELCOME TO ACCESS FORM!. CHOSE ANY PLAYER TO DELETE FROM WHITELIST AREA.", players_)
            .submitButton(warn+"§o§cREMOVE!")
            .show(player).then(r=>{
                if(r.canceled)return;
                const[v] = r.formValues;
                player.sendMessage(warn+"§aThis player has been removed from this area whitelist!!");
                player.playSound("random.levelup");
                areas.update(area.losha, v=>{
                    let nv=v;
                    nv.whitelist.splice(v, 1);
                    return nv;
                });
            });
    }
}

class Area {
    constructor(area) {
        this.right = Math.min(area.from.x, area.to.x);
        this.left = Math.max(area.from.x, area.to.x);
        this.bottom = Math.min(area.from.y, area.to.y);
        this.top = Math.max(area.from.y, area.to.y);
        this.back = Math.min(area.from.z, area.to.z);
        this.front = Math.max(area.from.z, area.to.z);
    }
}
class Main {
    static isInside (location, area) {
        const{x, y,z} = location;
        if(
                 x >= new Area(area).right &&
                 x <= new Area(area).left &&
                 y >= new Area(area).bottom &&
                 y <= new Area(area).top &&
                 z >= new Area(area).back &&
                 z <= new Area(area).front
        ) {
            return true;
        } else return false;
    }
    static getAreaByLocation (location) {
        const {x,y,z} = location;
        const findingArea = areas.all().find(
            (area) =>
                 x >= new Area(area).right &&
                 x <= new Area(area).left &&
                 y >= new Area(area).bottom &&
                 y <= new Area(area).top &&
                 z >= new Area(area).back &&
                 z <= new Area(area).front
        )
        if (findingArea) {
            return findingArea;
        } else return undefined;
    }
    static isOnline (playerName) {
        if (world.getPlayers().map(t=> t.name).includes(playerName)) return true; else return false;
    }
    
    static getPlayer (name) {
        return world.getPlayers().find(t => t.name == name );
    }
}

function dimensionCheck (area, player) {
    return area.dimension == player.dimension.id;
}
function getBlockFromFace(block, face) {
  switch (face) {
    case "Up": {
      return block.above();
    }
    case "Down": {
      return block.below();
    }
    case "North": {
      return block.north();
    }
    case "South": {
      return block.south();
    }
    case "East": {
      return block.east();
    }
    case "West": {
      return block.west();
    }
  }
}




world.beforeEvents.playerBreakBlock.subscribe((data) =>{
    const { player, block } = data;
    const area = Main.getAreaByLocation(block.location);
    if (area && dimensionCheck(area, player)) {
    if (player.hasTag("LoshaAdmin") || player.isOp() || area.owner == player.name || area.whitelist.includes(player.name)) return;
    if (area.settings.canBreakBlock == true) return;
    
    data.cancel = true;
        sendWarn(player, area);
    }
});





world.beforeEvents.playerPlaceBlock.subscribe(t => {
    const { player, block } = t;
    const area = Main.getAreaByLocation(block.location);
    if (area == undefined || player.hasTag("LoshaAdmin") || player.isOp()) return
    if (area.owner == player.name) return;
    
    t.cancel = true
    sendWarn(player, area)
});









world.beforeEvents.explosion.subscribe((data) =>{
    const areas_ =areas.all();
    const impactedBlocks = data.getImpactedBlocks();
    const blockIsInsideArea = areas_.some((area) => {
    return impactedBlocks.some((block) =>
      Main.isInside(block.location, area));
    });
    data.cancel = blockIsInsideArea;
});







world.beforeEvents.playerInteractWithBlock.subscribe((data) =>{
    const { block, player } = data;
    const area = Main.getAreaByLocation(block.location);
    if (area && dimensionCheck(area, player)) {
    if (player.hasTag("LoshaAdmin") || player.isOp() || area.owner == player.name || area.whitelist.includes(player.name)) return;
    
    data.cancel = !area.settings.interactWithBlocks;
    sendWarn(player, area)
    }
});


world.beforeEvents.itemUse.subscribe(t => {
    let { source, itemStack } = t
    let area = Main.getAreaByLocation(source.location)
    if (area == undefined) return
    if (source.hasTag("LoshaAdmin") || source.isOp() || area.owner == source.name || area.whitelist.includes(source.name)) return;
    if (area.settings.UseItems == true) return;
    if (itemStack.typeId.includes("losha")) return;
    if (area && dimensionCheck(area, source)) {
        t.cancel = !area.settings.UseItems;
        sendWarn(source, area)
    }
});


world.afterEvents.entityDie.subscribe(t => {
    const { deadEntity } = t
    const area = Main.getAreaByLocation(deadEntity.location)
    if (deadEntity.typeId.includes("player")&&area){
        if (Main.isOnline(area.owner)) Main.getPlayer(area.owner).onScreenDisplay.setActionBar(`${dieIcon}ßc There are player die in your area (${area.name})`)
    }
})


var sendWarn = (t, a) => {
    if (Main.isOnline(a.owner)) Main.getPlayer(a.owner).sendMessage(protectedIcon+" §cThere's an interaction player in your area ( " + a.name + " ).")
    t.sendMessage(protectedTotem+"§cThis is protected area.");
    system.run(() => t.playSound("random.break"));
}

world.afterEvents.itemUse.subscribe((data)=> {
    if (data.itemStack.typeId=="losha:lock"){
        mainForm(data.source);
    }
});














world.afterEvents.playerSpawn.subscribe((data) =>{
    const{player,initialSpawn}= data;
        const inventory = pInventory(player);
        const invIds = inventory.map(it=>it.typeId);
        if(!invIds.includes("losha:lock")) {
        player.runCommand('give @s losha:lock 1 0 {"item_lock":{"mode":"lock_in_inventory"}}');
        }
        if (!players.has(player.name)) {
             players.set(player.name, player.name);
        }
    
});


function adminpanel (player) {
    let form = new ActionFormData()
     .title("§o§f[ Admin Form ]")
     .body(`WELCOME ${player.name} TO ADMIN PANEL, ADMIN TAG: LoshaAdmin, ADMIN COMMAND: tag <target: target> LoshaAdmin, ${warn}THERE ARE ${areas.all().length} AREA IN THIS WORLD!!\n\n§eChat shorcut:\n§r;save - to save area losha\n;delete - to delete area by losha\n;remove - to delete the area you are in\n;informationOf - to show area information by losha\n;find - to find of the area you area in\n;deletelosha - to delete saved losha\n\n`)
     .button("SHOW AREAS FILTER\n"+downLine, "textures/items/losha_lock.png")
     .button("SET ADMIN\n"+downLine, "textures/ui/op.png")
     .button("CLEAR AREAS\n"+downLine, "textures/ui/icon_trash.png")
     .button("LIMIT SETTINGS\n"+downLine, "textures/ui/icon_saleribbon.png")
     .button("FIND AREAS\n"+downLine, "textures/ui/magnifyingGlass.png")
     .show(player).then(({ canceled, selection })=> {
         if (canceled) return;
         
         switch (selection) {
             case 0:
                 CHOSINGMENU(player);
                 break;
             case 1:
                 Admin_setAdmin(player);
                 break;
             case 2:
                     areas.clear();
                     player.sendMessage(warn+"§aAll areas has been deleted!!");
                     player.playSound("random.levelup");
                 
                 break;
             case 3:
                 Admin_Settings(player);
                 break;
             case 4:
                 getAreasByLosha(player);
                 break;
         }
     })
}

function Admin_setAdmin (player) {
    let form = new ActionFormData()
    .title("§o§f[ ADMIN FORM ]")
    .body("WELCOME TO (SET ADMIN) FORM!!. CHOSE PLAYER TO ADD TO ADMINS !!")
    
    world.getPlayers().forEach(p=>{
        form.button(`${p.name}\n${downLine}`, "textures/ui/icon_steve.png");
    })
    form.show(player).then(r=>{
        if (r.canceled) return;
        
        const playerSelected = world.getPlayers()[r.selection];
        if(playerSelected.hasTag("LoshaAdmin")){
            player.playSound("random.break");
            player.sendMessage(error+"§cHe ownes Admin!!..")
        } else {
            playerSelected.addTag("LoshaAdmin");
            player.sendMessage(warn+"§aHe joined to admins list!.");
            player.playSound("random.levelup");
        }
    });
}

function Admin_Settings (player) {
    let limit = limitData.has('limit')?limitData.get("limit"):"";
    let limitInfinty = limitData.has('limit')?limitData.get("limit"):"Infinty";
    const form = new ModalFormData()
         .title("§o§f[ ADMIN FORM ]")
         .textField(`§oWELCOME TO MOD SETTINGS!!, To return infinty write i!, \n\n${warn}MOD LIMIT.`, "MOD LIMIT IS ("+limitInfinty+")", limit)
         .submitButton(warn+"§o§aSAVE")
         .show(player).then(({ canceled, formValues })=> {
             if (canceled) return;
             
             if (!isNaN(formValues[0])){
                 limitData.set('limit', formValues[0])
                 player.sendMessage(warn+"§aDone change areas limit!!");
                 player.playSound("random.levelup");
             }else if (formValues[0] == "i"){
                 player.sendMessage(warn+"§aThe limit now is infinty!!");
                 player.playSound("random.levelup");
             } else {
                 player.sendMessage(error+"§cTHE LIMIT SHOULDE BE A NUMBER!!!.");
                 player.playSound("random.break");
             }
         })
}


function pInventory (p) {
    const inv = p.getComponent("inventory").container;
    const its = []
    
    for (let i=0;i<inv.size;i++){
        const it=inv.getItem(i)
        if(it){
            its.push(it);
        }
    }
    return its;
}

system.runInterval(()=> {
    world.getPlayers().forEach((player)=>{
        const { x, y, z } = player.location;

        const area = Main.getAreaByLocation(new Vector3(x, y, z));
        
        if (area && area.dimension == player.dimension.id) {
            const inv = player.getComponent("inventory").container;
            const handItem = inv.getItem(player.selectedSlotIndex);
            if (
                handItem &&
                handItem.typeId == "losha:lock"
                ) {
                let isAdmin = player.hasTag("LoshaAdmin");
            /*    if (isAdmin) {
                    const tag = player.getTags().find(tg=>tg.startsWith(`{"${player.name}":"losha":`))
                    if (tag && getSpliceKey(tag) != area.losha) {
                        system.run(
                             () => {
                                player.removeTag(tag)
                            }
                        )
                        player.addTag(`{"${player.name}":"losha":"${area.losha}"}`)
                    } else if (tag == undefined) {
                        player.addTag(`{"${player.name}":"losha":"${area.losha}"}`)
                    }
                }*/
                
                let from = new Vector3(area.from.x + 0.5, -64, area.from.z + 0.5);
                let to = new Vector3(area.to.x + 0.5, 319, area.to.z + 0.5);
                const corrner1 = { x: from.x, y: player.location.y, z: from.z };
                const corrner4 = { x: to.x, y: player.location.y, z: to.z };
                const corrner3 = { x: to.x, y: player.location.y, z: corrner1.z };
                const corrner2 = { x: corrner1.x, y: player.location.y, z: to.z };
                let Dimension = player.dimension;
                if (area.settings.showBorder == true ) {
                   dL(corrner1, corrner2, Dimension, 1);
                   dL(corrner2, corrner4, Dimension, 1);
                   dL(corrner4, corrner3, Dimension, 1);
                   dL(corrner3, corrner1, Dimension, 1);
                }
            }
            
            
        }
        
    })
}, 10);
system.runInterval(() => {
    world.getPlayers().forEach((player) => {
        const viewDirection = player.getBlockFromViewDirection({
            includeLiquidBlocks: !0,
            includePassableBlocks: !0,
            maxDistance: 6
        });
        const inv = player.getComponent("inventory").container;
        const handItem = inv.getItem(player.selectedSlotIndex);
            if (
                handItem &&
                handItem.typeId == "losha:lock"
            ) {
        
        if (viewDirection && viewDirection.block) {
            if (!coords.has(player)){
                 coords.set(player, []);
            }
            if (!runs.has(player)) {
                runs.set(player, [])
            }
            if(!cooldown.has(player)) {
                cooldown.set(player, 0);
            }
            const playerCoords = coords.get(player);
            const runsOfPlayer = runs.get(player);
            const clp = cooldown.get(player);
            if (Date.now() - clp < 1000) return;
            const {x,y,z} = viewDirection.block.location;
            const area = Main.getAreaByLocation(new Vector3(
                     x, y, z
                )
            )
            if (area) return;
            
            const c1 = playerCoords[0],
                  c2 = playerCoords[1];
            if (c1 && c2) return;
            if (
                `${x} ${y} ${z}` != c1 &&
                `${x} ${y} ${z}` != c2
            ) {
                player.dimension.spawnParticle(
                    "minecraft:electric_spark_particle",
                    new Vector3(x+0.5, y+1.5, z+0.5)
                )
                if (player.isJumping) {
                    const r = system.runInterval(() => {
                        player.dimension.spawnParticle("minecraft:electric_spark_particle", new Vector3(x+0.5, y+1.5, z+0.5));
                    });
                    player.playSound("random.levelup");
                    playerCoords.push(`${x} ${y} ${z}`);
                    runsOfPlayer.push(r);
                    cooldown.set(player, Date.now())
                }
            }
          }
        }
    })
})

function dL (from, to, dimension, gap) {
  let locs = [];
  let direction = Vector3.multiply(Vector3.subtract(to, from).normalized(), gap),
    counts = Math.ceil(Vector3.distance(from, to) / gap);
  for (let loc = from; counts--; )
    locs.push((loc = Vector3.add(loc, direction)));
  for (const loc of locs)
    dimension.spawnParticle("minecraft:electric_spark_particle", loc);
}
/*function getParticels (player) {
    const particels = []
    const c1 = player.getTags().find(tag =>
         tag.startsWith(`{"c1":`)
    );
    const c2 = player.getTags().find(tag =>
         tag.startsWith(`{"c2":`)
    );
    particels.push(
        c1?c1.split('{"c1":')[1].replace("}", ""):undefined);
    particels.push(
        c2?c2.split('{"c2":')[1].replace("}", ""):undefined);
    return particels;
}
function getRuns (player) {
    const runs = []
    const run1 = player.getTags().find(
        (tag) => tag.startsWith(`{"run1":`)
    );
    const run2 = player.getTags().find(
        (tag) => tag.startsWith(`{"run2":`)
    );
    if (run1) {
    runs.push(
        run1?run1.split(`{"run1":`)[1].replace("}", ''):undefined)}
    if (run2) {
    runs.push(
        run2?run2.split(`{"run2":`)[1].replace("}", ''):undefined)}
    return runs;
}*/
function generateAreaWhitlist (area) {
    let result = ''
    
    area.whitelist.forEach((player) => result += `${player}, `);
    return result==''?"§4No thing.":result;
}

function Admin_allAreas (player) {
    let form = new ActionFormData()
       .title("§o§f[ ALL AREAS ]")
       .body(warn+"Hello, Chose player to show areas!?")
       
       getPlayers().forEach((p) => {
           let icon = "\uE060";
           
           if (p.online) icon = "\uE072";
           const length = areas.all().filter(a => a.owner == p.name).length
           form.button(`${icon} ${p.name.replace(/ /g, "_")}\n§aAREAS§r - §b${length}`, "textures/ui/icon_steve.png")
       })
       
       form.show(player).then(({ canceled, selection }) =>{
           if (canceled) return;
           
           const player_ = getPlayers()[selection];
           
           if (player_ !== undefined) {
               const playerAreas = areas.all().filter(a => a.owner == player_.name);
               const r = system.runInterval(() => {
                   player.onScreenDisplay.setActionBar(
                       `${waitingIcon}§c Waiting for areas.`
                   );
               })
               system.runTimeout(() => {
                   system.clearRun(r);
                   if (playerAreas.length == 0) {
                       let form_ = new ActionFormData()
                            .title(errorIcon)
                            .body(`${error}§c ${player_.name} don't have areas!?.`)
                            .button(playerIcon+" TRY AGIN\n"+   downLine)
                            .show(player).then(r => {
                                if (r.canceled) return;
                                if (r.selection == 0) Admin_allAreas(player);
                                
                            })
                   } else {
                       let form_ = new ActionFormData()
                          .title(player_.name)
                          .body(`${warn}§a${player_.name} have ${playerAreas.length} area!`)
                          
                          playerAreas.forEach(area => {
                              form_.button(`${glassFind}§r - ${convertCaptial(area.name)}\n§c@${area.losha}`)
                          })
                          form_
                             .button(glassFind+"TRY AGIN\n"+downLine)
                             .show(player).then(r => {
                                 if (r.canceled) return;
                                 
                                 if (r.selection == playerAreas.length) {
                                     Admin_allAreas(player);
                                     return;
                                 }
                                 
                                 const area = playerAreas[r.selection];
                                 if (area) {
                                     const{x,y,z} = area.from;
                 const tx=area.to.x,
                       ty=area.to.y,
                       tz=area.to.z;
                let form = new ActionFormData()
                .title(area.name)
                .body(`${warn}§aAREA NAME§r - §b${area.name}\n${warn}§aAREA FROM§r - §b${x+", "+y+", "+z}\n${warn}§aAREA TO§r - §b${tx+", "+ty+", "+tz}\n${warn}§aAREA LAND§r - §b${land(area.from, area.to)}\n${warn}§aAREA WHITLIST§r - §b${generateAreaWhitlist(area)}\n${warn}§aLOSHA AREA§r - §b${area.losha}\n${warn}§aAREA OWNER§r - §b${area.owner}`)
                .button("DELETE AREA\n"+downLine, "textures/ui/icon_trash.png")
                .button("TELEPORT TO AREA\n"+downLine, "textures/ui/ChainSquare.png")
                .show(player).then(r=>{
                    if (r.canceled) return;
                    switch (r.selection) {
                        case 0:
                            areas.delete(area.losha);
                            player.sendMessage(warn+"§aThe area has been deleted!!");
                            player.playSound("random.levelup");
                            break;
                        case 1:
                            player.teleport(new Vector3(x, area.y_, z), { dimension: world.getDimension(area.dimension) });
                            player.playSound("random.levelup");
                            break;
                    }
                })
                                 }
                             })
                   }
               }, 60)
           }
       })
}

function creators (player) {
    const form = new ActionFormData()
        .title("§o§f[ CREATORS ]")
        .body(`${warn}§aThere are two creators to this mod!,§f the particle and icons in mod by §4MAHMOOD§f, and the sounds and items and main script by §bRIDA12940`)
        .button(`${youtube}§r - §l§4YOU§fTUBE\n§r§b§o@${convert("بازوكا")}`,
         "textures/creators/youtubeIcon.png"
        )
        .button(`${warn}§b§lRIDA12940\n§r§b§o@RIDA12940`, "textures/creators/RIDA.png")
        .button(`${warn}§4§lMAHMOOD\n§r§4§o@MAHMOOD`, "textures/creators/MAHMOOD.png")
        .show(player)
        .then(r=>{
            if (r.canceled) return;
        })
}

system.runInterval(() => {
    world.getPlayers().forEach(player => {
        const {x,y,z} = player.location;
        const area = Main.getAreaByLocation(new Vector3(x, y, z));
        
        if (area && area.dimension == player.dimension.id) {
            if (area.settings.exclusionPlayers == true) {
                if (area.owner != player.name || !player.hasTag("LoshaAdmin") || !player.isOp() || !area.whitelist.includes(player.name)) {
                if (Main.isInside(new Vector3(area.from.x+1, area.y_, area.from.z+1))) {
                    player.teleport(new Vector3(area.from.x-1, area.y_, area.from.z-1));
                } else {
                    player.teleport(new Vector3(area.from.x+1, area.y_, area.from.z+1));
                }
                }
            }
            if (area.settings.killPlayers == true && (area.owner != player.name || !isAdmin(player) || !area.whitelist.includes(player.name))) {
                player.kill();
            }
        }
    })
});

world.beforeEvents.chatSend.subscribe((data) => {
    const { message, sender } = data;
    
    if (message.startsWith(";")) {
        system.run(() => {
        if (isAdmin(sender)) {
        if (message.startsWith(";delete ")) {
            const loshaOfArea = message.split(" ");
            if (!loshaOfArea[1].endsWith("Area")) {
                sender.sendMessage(error+`§cThe losha should be ends with "Area"!.`);
                return;
            }
            
            if (areas.has(loshaOfArea[1])) {
                areas.delete(loshaOfArea[1])
                sender.sendMessage(warn +`§aThe area has been deleted!.`)
            } else sender.sendMessage(error+`§cThere are no area with this losha!.`)
        } else if (message == ";remove") {
            const area = Main.getAreaByLocation(sender.location);
            
            if (area) {
                areas.delete(area.losha);
                sender.sendMessage(warn+"§aThe area has been deleted!.")
                sender.playSound("random.levelup")
            } else {
                sender.sendMessage(error+"§cYou is not in area.")
                sender.playSound("random.break")
            }
        } else if (message == ";save") {
            const area = Main.getAreaByLocation(sender.location);
            
            if (area) {
                const tag = sender.getTags().find(t => t.startsWith(`{"${sender.name}":"losha":`))
                if (tag) {
                    system.run(() => sender.removeTag(tag))
                    sender.addTag(`{"${sender.name}":"losha":"${area.losha}"}`);
                    sender.sendMessage(warn+"§aThe losha has been saved.")
                    sender.playSound("random.levelup")
                } else{
                sender.addTag(`{"${sender.name}":"losha":"${area.losha}"}`);
                sender.sendMessage(warn+"§aThe losha has been saved.")
                sender.playSound("random.levelup")
               }
            }
        } else if (message == ";find") {
            const area = Main.getAreaByLocation(sender.location);
            
            if (area) {
                const{x,y,z} = area.from;
                const tx=area.to.x,
                      ty=area.to.y,
                      tz=area.to.z;
                sender.sendMessage(`${warn}§aAREA NAME§r - §b${area.name}\n${warn}§aAREA FROM§r - §b${x+", "+y+", "+z}\n${warn}§aAREA TO§r - §b${tx+", "+ty+", "+tz}\n${warn}§aAREA LAND§r - §b${land(area.from, area.to)}\n${warn}§aAREA WHITLIST§r - §b${generateAreaWhitlist(area)}\n${warn}§aLOSHA AREA§r - §b${area.losha}\n${warn}§aAREA OWNER§r - §b${area.owner}`)
                sender.playSound("random.levelup")
            } else {
                sender.sendMessage(error+"§cYou is not in area.");
                sender.playSound("random.break");
            }
        } else if (message.startsWith(";informationOf ")) {
            const losha = message.split(" ");
            
            if (!losha[1].endsWith("Area")) {
                sender.sendMessage(error+'§cThe losha should be ends with "Area"')
                return;
                sender.playSound("random.break");
            }
            
            if (areas.has(losha[1])) {
                const area = areas.get(losha[1]);
                const{x,y,z} = area.from;
                const tx=area.to.x,
                      ty=area.to.y,
                      tz=area.to.z;
                sender.sendMessage(`${warn}§aAREA NAME§r - §b${area.name}\n${warn}§aAREA FROM§r - §b${x+", "+y+", "+z}\n${warn}§aAREA TO§r - §b${tx+", "+ty+", "+tz}\n${warn}§aAREA LAND§r - §b${land(area.from, area.to)}\n${warn}§aAREA WHITLIST§r - §b${generateAreaWhitlist(area)}\n${warn}§aLOSHA AREA§r - §b${area.losha}\n${warn}§aAREA OWNER§r - §b${area.owner}`);
                sender.playSound("random.levelup");
            } else {
                sender.sendMessage(error+"§cThere are no area with this losha.");
                sender.playSound("random.break")
            }
          } else if (message == ";deletelosha") {
              const tag = sender.getTags().find(t => t.startsWith(`{"${sender.name}":"losha":`))
              if (tag) {
                  sender.removeTag(tag);
                  sender.sendMessage(warn+"§aThe losha has been deleted!")
                  sender.playSound("random.levelup");
              } else {
                  sender.sendMessage(error+"§cYou don't saved any losha!");
                  sender.playSound("random.break")
              }
          } else {world.sendMessage(`<${sender.name}> ${convert(message)}`)}
        }
        if (message == ";deleteCoords") {
            if (coords.has(sender)) {
                for (let run of runs.get(sender)) system.clearRun(run);
                sender.sendMessage(warn+"§aThe coords has been deleted!")
                sender.playSound("random.levelup");
                coords.delete(sender)
                runs.delete(sender)
                cooldown.delete(sender)
            } else sender.sendMessage(error+"§cYou don't saved any coords!");
        }
        })
    
        data.cancel = true;
    } else {
        data.cancel=true;
        world.sendMessage(`<${sender.name}> ${convert(message)}`);
    }
});


function getSpliceKey (tag) {
    return tag.split(`:`)[2].replace(/"/g, "").replace("}", "");
}

function areaSettings (player, area) {
    let form = new ModalFormData()
         .title(area.name+" SETTINGS")
         .toggle(warn+"ITEM USE IN AREA?", area.settings.UseItems)
         .toggle(warn+"BREAK BLOCK IN AREA?", area.settings.canBreakBlock)
         .toggle(warn+"SHOW INFORMATION OF AREA?", area.settings.showInformation)
         .toggle(warn+"SHOW AREA BORDER?", area.settings.showBorder)
         .toggle(warn+"INTERACT WITH BLOCKS?", area.settings.interactWithBlocks);
         form
         .submitButton(warn+"§aSAVE")
         .show(player)
         .then(r=>{
             if(r.canceled) return;
             const [useItems, breakBlocks, showInformation, showBorder, I] = r.formValues;
             areas.update(area.losha, v => {
                 let nv = v;
                 nv.settings.UseItems = useItems;
                 nv.settings.canBreakBlock = breakBlocks;
                 nv.settings.showInformation = showInformation;
                 nv.settings.showBorder = showBorder;
                 nv.settings.interactWithBlocks = I
                 return nv;
             });
             player.playSound("random.levelup");
             player.onScreenDisplay.setActionBar(warn+`§aThe settings has been saved ${settingsIcon1}!`);
         })
}



function getAreaCeneter (area) {
    const fx = area.from.x,
          fy = area.from.y,
          fz = area.from.z,
          tx = area.to.x,
          ty = area.to.y,
          tz = area.to.z;
    
    const line1 = new Vector3(fx, area.y_, tz);
    const line2 = new Vector3(tx, area.y_, fz);
    
    const linesCenter = [Math.floor(line1 / 2), Math.floor(line2 / 2)];
    let result = new Vector3(fx - linesCenter[0], area.y_, fz - linesCenter[1]);
    if (Main.isInside(new Vector3(fx + linesCenter[0], area.y_, fz + linesCenter[1]))) {
        result = new Vector3(fx + linesCenter[0], area.y_, fz + linesCenter[1])
    }
    
    return result;
}

function getAreasByLosha (player) {
    let tag = player.getTags().find(loshaTag => loshaTag.startsWith(`{"${player.name}":"losha":`));
    let losha = "";
    if (tag) {
        losha = getSpliceKey(tag);
    }
    let form = new ModalFormData()
       .title("§f§o[ FIND AREAS ]")
       .textField(warn+"§aENTER ANY LOSHA!", "example: RIDA12940_YIA18Area", losha)
       .submitButton(warn+"§bFIND")
       .show(player)
       .then(({ canceled, formValues }) => {
           if (canceled) {
               if (tag) {
               system.run(() => player.removeTag(tag));
               }
               return;
           }
           const [losha_] = formValues;
           if (!losha_.endsWith("Area")) {
               player.sendMessage(error+'§cThe losha should be ends with "Area"!.');
               return;
           }
           const loshaAreas = areas.all().filter(areaLosha => areaLosha.losha.includes(losha_));
           
           const r = system.runInterval(() => {
               player.onScreenDisplay.setActionBar(`${glassFind}§c Waiting for areas.`);
           })
           system.run(() => player.removeTag(tag));
           system.runTimeout(() => showAreas(player, loshaAreas, r, losha_), 60);
       })
}

function showAreas (player, loshaAreas, run, losha_) {
    system.clearRun(run);
    if (loshaAreas.length == 0) {
               let form = new ActionFormData()
                  .title(errorIcon)
                  .body(error+"§cThere are 0 area with this losha, try another losha\n§eresults of "+losha_+":")
                  .button(glassFind+" TRY AGIN\n"+downLine)
                  .show(player).then((r) => {
                      if (r.canceled) return;
                      if (r.selection == 0) getAreasByLosha(player);
                  });
           } else {
               let form = new ActionFormData()
                 .title("§f§oALL AREAS WITH "+losha_)
                 .body(`${warn}§aThere are ${loshaAreas.length} with this losha!,\n§eresults of ${losha_}:`)
                 
                 loshaAreas.forEach(area =>{
                     form.button(`${glassFind}§r - ${convertCaptial(area.name)}\n§c@${area.losha}`)
                 })
                 form.button(glassFind+"§r - §4§oFIND AGIN\n"+downLine)
                 form.show(player).then(r=> {
                     if (r.canceled) return;
                     
                     const area = loshaAreas[r.selection];
                     if (r.selection == loshaAreas.length) {
                         getAreasByLosha(player);
                         return;
                     }
                     if (area) {
                         const{x,y,z} = area.from;
                 const tx=area.to.x,
                       ty=area.to.y,
                       tz=area.to.z;
                let form = new ActionFormData()
                .title(area.name)
                .body(`${warn}§aAREA NAME§r - §b${area.name}\n${warn}§aAREA FROM§r - §b${x+", "+y+", "+z}\n${warn}§aAREA TO§r - §b${tx+", "+ty+", "+tz}\n${warn}§aAREA LAND§r - §b${land(area.from, area.to)}\n${warn}§aAREA WHITLIST§r - §b${generateAreaWhitlist(area)}\n${warn}§aLOSHA AREA§r - §b${area.losha}\n${warn}§aAREA OWNER§r - §b${area.owner}`)
                .button("DELETE AREA\n"+downLine, "textures/ui/icon_trash.png")
                .button("TELEPORT TO AREA\n"+downLine, "textures/ui/ChainSquare.png")
                .show(player).then(r=>{
                    if (r.canceled) return;
                    switch (r.selection) {
                        case 0:
                            areas.delete(area.losha);
                            player.sendMessage(warn+"§aThe area has been deleted!!");
                            player.playSound("random.levelup");
                            break;
                        case 1:
                            player.teleport(new Vector3(x, area.y_, z), { dimension: world.getDimension(area.dimension) });
                            player.playSound("random.levelup");
                            break;
                    }
                })
                     }
                 })
           }
}

function getPlayers () {
    let result_ = players.all();
    let result = [];
    
    result_.forEach(t=>{
        let isOnline = false;
        if (world.getPlayers().map(p => p.name).includes(t)) {
            isOnline = true
        }
        result.push({ name: t, online: isOnline });
    });
    return result;
}

function CHOSINGMENU (player) {
    let form = new ActionFormData()
         .title("§o§f[ AREAS ]")
         .body(warn+"Hello, there are 3 filters to show areas "+protectedIcon)
         .button(`${playerIcon} PLAYERS FILTER\n${downLine}`)
         .button(`${diamondIcon} DIMENSIONS FILTER\n${downLine}`)
         .button(`${protectedIcon} SHOW ALL\n${downLine}`)
         .show(player).then(({ canceled, selection }) => {
             if (canceled) return;
             
             switch (selection) {
                 case 0:
                     Admin_allAreas(player);
                     break;
                 case 1:
                     DimensionsFilter(player);
                     break;
                 case 2:
                     AllAreas(player);
                     break;
             }
         })
}

function DimensionsFilter (player) {
    let dimensions = ["overworld", "nether", "the_end"];
    let form = new ActionFormData()
        .title("§o§f[ DIMENSIONS ]")
        .body(warn+"Dimension filter!. "+diamondIcon)
        
        dimensions.forEach((dim) => {
            let color = dim == "overworld" ? "§a" : dim == "nether" ? "§4" : "§p";
            form.button(`${diamondIcon} ${color + dim}\n${downLine}`);
        })
        
        form.show(player).then(({ canceled, selection }) => {
            if (canceled) return;
            
            const dimension = dimensions[selection];
            const dimensionAreas = areas.all().filter(
                (area) =>
                    area.dimension == `minecraft:${dimension}`
            );
            let r = system.runInterval(() => player.onScreenDisplay.setActionBar(`${waitingIcon}§a Wait for areas.`))
            system.runTimeout(() => {
                system.clearRun(r);
            if (dimensionAreas.length != 0) {
                let color = dimension == "overworld" ? "§a" : dim == "nether" ? "§4" : "§p";
                const forms = new ActionFormData()
                    .title(color+dimension)
                    .body(warn+`welcome to ${color+dimension} ${diamondIcon} areas!,`)
                    
                    dimensionAreas.forEach((area) => {
                        forms.button(`${glassFind}§r -  ${convertCaptial(area.name)}\n${downLine}`)
                    })
                    forms.show(player).then(i => {
                        if (i.canceled) return;
                        
                        const area = dimensionAreas[i.selection];
                        
                        if (area) {
                            const{x,y,z} = area.from;
                 const tx=area.to.x,
                       ty=area.to.y,
                       tz=area.to.z;
                let form = new ActionFormData()
                .title(area.name)
                .body(`${warn}§aAREA NAME§r - §b${area.name}\n${warn}§aAREA FROM§r - §b${x+", "+y+", "+z}\n${warn}§aAREA TO§r - §b${tx+", "+ty+", "+tz}\n${warn}§aAREA LAND§r - §b${land(area.from, area.to)}\n${warn}§aAREA WHITLIST§r - §b${generateAreaWhitlist(area)}\n${warn}§aLOSHA AREA§r - §b${area.losha}\n${warn}§aAREA OWNER§r - §b${area.owner}`)
                .button("DELETE AREA\n"+downLine, "textures/ui/icon_trash.png")
                .button("TELEPORT TO AREA\n"+downLine, "textures/ui/ChainSquare.png")
                .show(player).then(r=>{
                    if (r.canceled) return;
                    switch (r.selection) {
                        case 0:
                            areas.delete(area.losha);
                            player.sendMessage(warn+"§aThe area has been deleted!!");
                            player.playSound("random.levelup");
                            break;
                        case 1:
                            player.teleport(new Vector3(x, area.y_, z), { dimension: world.getDimension(area.dimension) });
                            player.playSound("random.levelup");
                            break;
                    }
                })
                        }
                    })
            }else{
                let fom = new ActionFormData()
                   .title(errorIcon)
                   .body(error+`§cThere are 0 area in this dimension ${dimension} ${diamondIcon}`)
                   .button(glassFind+" - TRY ANOTHER DIMENSION\n"+downLine)
                   .show(player)
                   .then(({ canceled, selection }) =>{
                       if (canceled) return;
                       
                       if (selection == 0) DimensionsFilter(player);
                   })
            }
        }, 60)
        })
}

function convertCaptial (src) {
    return src.replace(/q/g, 'Q').replace(/w/g, 'W').replace(/e/g, 'E').replace(/r/g, "R").replace(/t/g, 'T').replace(/y/g, 'Y').replace(/u/g, "U").replace(/i/g, 'I').replace(/o/g, 'O').replace(/p/g, "P").replace(/a/g, "A").replace(/s/g, 'S').replace(/d/g, "D").replace(/f/g, "F").replace(/g/g, "G").replace(/h/g, "H").replace(/j/g, "J").replace(/k/g, "K").replace(/l/g, "L").replace(/z/g, "Z").replace(/x/g, "X").replace(/c/g, "C").replace(/v/g, "V").replace(/b/g, "B").replace(/n/g, "N").replace(/m/g, "M").replace(/ /g, "_");
}

function AllAreas (t) {
    let r = system.runInterval(() => player.onScreenDisplay.setActionBar(`${waitingIcon}§a Wait for areas.`))
    system.runTimeout(() => {
        system.clearRun(r);
    let form = new ActionFormData()
    .title("§o§f[ All Areas ]")
    .body(warn+`Hello!, this is all areas!, there are ${areas.all().length} area in this world!,`)
    
    areas.all().forEach(i => form.button(`${glassFind} - ${convertCaptial(i.name)}\n${i.owner}`))
    form.show(t).then(s=> {
        if (s.canceled) return
        const area = areas.all()[s.selection]
        
        if (area) {
           let player = t
            const{x,y,z} = area.from;
                 const tx=area.to.x,
                       ty=area.to.y,
                       tz=area.to.z;
                let form = new ActionFormData()
                .title(area.name)
                .body(`${warn}§aAREA NAME§r - §b${area.name}\n${warn}§aAREA FROM§r - §b${x+", "+y+", "+z}\n${warn}§aAREA TO§r - §b${tx+", "+ty+", "+tz}\n${warn}§aAREA LAND§r - §b${land(area.from, area.to)}\n${warn}§aAREA WHITLIST§r - §b${generateAreaWhitlist(area)}\n${warn}§aLOSHA AREA§r - §b${area.losha}\n${warn}§aAREA OWNER§r - §b${area.owner}`)
                .button("DELETE AREA\n"+downLine, "textures/ui/icon_trash.png")
                .button("TELEPORT TO AREA\n"+downLine, "textures/ui/ChainSquare.png")
                .show(player).then(r=>{
                    if (r.canceled) return;
                    switch (r.selection) {
                        case 0:
                            areas.delete(area.losha);
                            player.sendMessage(warn+"§aThe area has been deleted!!");
                            player.playSound("random.levelup");
                            break;
                        case 1:
                            player.teleport(new Vector3(x, area.y_, z), { dimension: world.getDimension(area.dimension) });
                            player.playSound("random.levelup");
                            break;
                    }
                })
        }
    })
}, 60)
}

function accessOptins (player, area) {
    let form = new ActionFormData()
      .title(`§o§f[ ${area.name} access list ]`)
      .body(`${warn}§aHello!!?, this form for access list of ${area.name}`)
      .button(`ADD ACCESS\n`+downLine, "textures/ui/color_plus.png")
      .button("REMOVE ACESS\n"+downLine, "textures/ui/icon_trash.png")
      .show(player)
      .then(t => {
          if (t.canceled) return
          
          switch (t.selection) {
              case 0: addAccess(player, area); break;
              case 1: deleteAccess(player, area); break;
              case 2:
                  if (area.whitelist.length <=0) {
                      player.sendMessage(error+"§cThe area whitelist length is 0!.")
                      return;
                  }
                  let formOf = new ActionFormData()
                     .title("§o§f[ ACCESS SETTINGS ]")
                     .body(warn+`§aHello!?, this form to edit players access`)
                     
                     area.whitelist.forEach(r => formOf.button(`${convertCaptial(r.name)}\n${downLine}`, "textures/ui/permissions_member_star.png"))
                     
                     formOf.show(player).then(i => {
                         if (i.canceled) return
                         
                         const playerAccess = area.whitelist[i.selection];
                         
                         if (playerAccess) {
                             let nForm = new ModalFormData()
                                .title(playerAccess.name)
                                .toggle(warn+"CAN BREAK BLOCKS?", playerAccess.settings.canBreakBlock)
                                .toggle(warn+"CAN PLACE BLOCK?", playerAccess.settings.canPlaceBlock)
                                .toggle(warn+"OPEN CHESTS?", playerAccess.settings.openChests)
                                .toggle(warn+"USE ITEMS?", playerAccess.settings.UseItems)
                                .submitButton(warn+"§aSAVE")
                                .show(player).then(s => {
                                    if (s.canceled) return
                                    const [v1, v2, v3, v4] = s.formValues;
                                    areas.all().update(area.losha, v => {
                                        let nv = v
                                        let p = nv.whitelist.find(a => a.name == playerAccess.name)
                                        if (p) {
                                            p.settings.canBreakBlock=v1;
                                            p.settings.canPlaceBlock=v2;
                                            p.settings.openChests=v3;
                                            p.settings.UseItems=v4;
                                        }
                                        return nv;
                                    });
                                    player.sendMessage(warn+"§aTHE SETTINGS HAS BEEN SAVED!!.")
                                    player.playSound("random.levelup");
                                })
                         }
                     })
                  break
          }
      })
}

system.runInterval(() => {
    world.getPlayers().forEach((player) =>{
        const inv = player.getComponent("inventory").container;
        let items = [];
        for (let i = 0; i < inv.size; i++) {
            let item = inv.getItem(i);
            
            if (item && item.typeId == "losha:lock") items.push({ item, slotOf: i })
        }
        
        for (let { item, slotOf } of items) {
             if (player.hasTag("LoshaAdmin") || player.isOp()) {
                 item.nameTag = "§aAREAS &§e ADMIN";
                 item.setLore([`${warn}§bYour areas§r - §o${areas.all().filter( t => t.owner == player.name).length}`, '', '', ''])
             } else {
                 item.nameTag = "§aAREAS";
                 item.setLore([`${warn}§bYour areas§r - §o${areas.all().filter( t => t.owner == player.name).length}`, '', '', '']);
             }
             inv.setItem(slotOf, item);
        }
    });
});

function howToUse (player) {
    let form = new ActionFormData()
       .title(`§f§o[ HOW TO USE? ${settingsIcon1} ]`)
       .body(`Hello this is §blosha §alock §dmod§r\n\n${warn}§athis mod was created by losha mods\n\n\uE072§d losha mod link §r- https://loshamod.blogspot.com\n\n§b\uE062mod version§r - v1.0, wating for another versions \uE066!\n\n§r- HOW TO USE?\n\n       §a- create area :\n§rOpen main menu and press create area button, write information like area from, area to and area name,\n\n       §b- delete area :\n§rGo to delete areas and selecte any area and confirm the deleted\n\n       §e- add player to area access:§r\nGo to my areas button and selecte your area and go to "ACCESS OPTINS" and selecte "ADD ACCESS" and chose the player\n\n       §d- delete player from area access:\n§rGo to my areas button and selecte your area and go to "ACCESS OPTINS" button and chose "REMOVE ACCESS" and chose the player\n\n      §t- edit area settings:§r\nGo to my areas and chose your area and selecte "AREA SETTINGS" button\n\n   §4${youtube}§d Losha mod youtube§r - https://youtube.com/channel/UCDAAbPftmNMF8XrcFXUg6ag?si=Kua0MGZa3Q7x5XMZ`)
       .button("CLOSE\n"+downLine)
       .show(player).then(r => {
           if (r.canceled) return;
           
       })
}

function isAdmin (player) {
    if (player.hasTag("LoshaAdmin") || player.isOp()) return true; else return false;
}