import { world, system, Player } from '@minecraft/server'



class Storage {
    #storage = new Map()
    constructor(Name) {
        this.Name = Name
        
        this.#storage = new Map()
        
        this.database = new DATABASE(this.Name)
        
        let deleted = 0
        let saved = 0
        for (const pro of this.database.forAll()) {
                try {
                     this.#storage.set(pro.key, pro.value)
                     saved++
                } catch {
                    this.database.deleteIn(pro.key)
                    deleted++
                }
            }
    }
    
    get (key) {
        try {
          if (this.has(key)) {
              return this.#storage.get(key)
           } else return undefined
      } catch (e) { 
          console.error(e)
      }
    }
    
    #setInDataBase (key, value) {
        try {
            if (this.#hasInDatabase(key)) this.#deleteInDatabase(key)
            this.database.setIn(key, value)
            
        } catch (e) {
            console.error(e)
        }
    }
    
    #hasInDatabase (key) {
        try {
            return this.database.hasIn(key)
        } catch (e) {
            console.error(e)
        }
    }
    
    #deleteInDatabase (key) {
        try {
            this.database.deleteIn(key)
        } catch (e) {
            console.error(e)
        }
    }
    
    set (key, value) {
        try {
        if (this.has(key)) this.delete(key)
        if (this.#hasInDatabase(key)) this.deleteInDatabase(key)
        
        
          this.#storage.set(key, value)
          this.#setInDataBase(key, value)
      } catch (e) {
          console.error(e)
      }
    }
    
    has (key) {
        try {
            return this.#storage.has(key)
        } catch (e) {
            console.error(e)
        }
    }
    
    delete (key) {
        try {
            if (this.has(key)) {
                this.#storage.delete(key)
                this.#deleteInDatabase(key)
            } else {
                console.error(`§d§l${key}§r is undefined`)
            }
        } catch (e) {
            console.error(e)
        }
    }
    
    update (key, callback) {
        try {
            const outputValue = callback(this.get(key))
            
            this.set(key, outputValue)
        } catch (e) { console.error(e) }
    }
    
    keys () {
        return this.#storage.keys()
    }
    
    values () {
        return this.#storage.values()
    }
    
    entries () {
        return this.#storage.entries()
    }
    
    clear () {
        this.#storage.clear()
        this.database.clear()
    }
    
    size () {
        return this.#storage.size
    }
    
    all () {
        try {
            let storageArray = []
            
            this.#storage.forEach((map) => {
                storageArray.push(map)
            })
            
            return storageArray
        } catch (e) { console.error(e) }
    }
}




class DATABASE {
    constructor(name) {
        this.name = name
        
        try {
            if (!world.getDynamicProperty(`${this.name}_SAVED?`)){
                world.setDynamicProperty(`${this.name}_SAVED?`, JSON.stringify([]))
            }
        } catch (e) {
            console.error(e)
        }
    }
    
    forAll () {
        return JSON.parse(world.getDynamicProperty(`${this.name}_SAVED?`))
    }
    
    setIn (key, value) {
        try {
            if (this.hasIn(key)) this.deleteIn(key)
            
            const all = this.forAll()
            
            all?.push({ key, value })
            
            this.UPDATEID(all)
        } catch (e) {
            console.error(e)
        }
    }
    
    deleteIn (key) {
        try {
            if (this.hasIn(key)) {
                const all = this.forAll()
                const index = all?.findIndex(id => id.key == key)
                
                if (index == -1) console.error(index)
                if (index <= -1) return
                all?.splice(index,1)
                
                this.UPDATEID(all)
            }
        } catch (e) {
            console.error(e)
        }
    }
    
    hasIn (key) {
        try {
            const v = this.forAll()?.find(id => id.key == key)
            if (v) { return true } else return false
        } catch (e) {
            console.error(e)
        }
    }
    
    UPDATEID (data) {
        world.setDynamicProperty(
            `${this.name}_SAVED?`, JSON.stringify(data)
            )
    }
    
    clear () {
        let emptyArray = []
        
        this.UPDATEID(emptyArray)
    }
}


export { Storage }
